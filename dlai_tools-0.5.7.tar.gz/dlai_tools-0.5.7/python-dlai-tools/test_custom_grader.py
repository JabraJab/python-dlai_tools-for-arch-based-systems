from custom_grader import deploy_assignment

deploy_assignment('./example_notebooks/example_Dev.ipynb', True)
print("Test passed. At least is running")