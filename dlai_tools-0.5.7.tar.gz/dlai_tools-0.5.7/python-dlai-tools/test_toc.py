from toc import add_toc

add_toc('./example_notebooks/C4_W4_Assignment_Solution.ipynb')
print("Test passed. At least is running")

