# dlai_tools

A set of tools for [DeepLearning.AI](https://www.deeplearning.ai/). 

# Usage

## Install

`pip install dlai_tools`

## Add table of content

`python -m dlai_tools.toc Name_of_Notebook.ipynb  [patterns.json templates.json]`

You can change the style of your table of content by changing the default patterns and templetes. You can pass 2 json files containing the new set of patterns and templates. This will be described properly later.

### default_patterns
```
default_patterns = {
    'section': ['^## [0-9]+ - '], # '- [Part {section_number}: {section_title}](# {section_number})'
    'subsection': ['^### [0-9]+.[0-9]+ '], 
    'exercise': ['^### Exercise [0-9]+'], 
    'toc_title': ['^# Outline']
}
```

### dafault_template

```
default_templates = {
    'section': '## {section_number} - {section_title}', 
    'subsection': '### {section_number}.{subsection_number} {subsection_title}', 
    'exercise': '### Exercise {exercise_number}', 
    'toc_title': '# Outline'
}
```

It produces a file called Name_of_Notebook_toc.ipynb

## Create learner facing version

`python -m dlai_tools.learner_generator Name_of_Notebook.ipynb [tags.json]`

It produces a file called Name_of_Notebook_Assignment.ipynb

You can change the style of your table of content by changing the default tags. You can pass a path to a json file containing the new set of tags.

```
defaul_tags =  {
    'tagStartCode': "START CODE HERE",
    'tagEndCode': "END CODE HERE",
	'tagStartOmitBlock': "START OMIT BLOCK",
	'tagEndOmitBlock': "END OMIT BLOCK",
	'tagOmit': "@OMIT",
	'tagKeep': "@KEEP",
	'tagReplaceEquals': "@REPLACE EQUALS",
	'tagReplace': "@REPLACE",
}
```

# Testing utils

You can import from your python code, a set of functions that helps in the testing process.

```
from dlai_tool.testing_utils import *

datatype_check("abc", "csf", "Error")
...
```